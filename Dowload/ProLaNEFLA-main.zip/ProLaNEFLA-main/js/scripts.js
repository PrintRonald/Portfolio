$(document).ready(function(){
  $("#flip").mouseenter(function(){
    $("#panel").slideToggle("slow");
  })

  $("#flip1").mouseenter(function(){
    $("#panel1").slideToggle("slow");
  })

  $("#flip2").mouseenter(function(){
    $("#panel2").slideToggle("slow");
  })

  $("#flip3").mouseenter(function(){
    $("#panel3").slideToggle("slow");
  })

  $("#flip4").mouseenter(function(){
    $("#panel4").slideToggle("slow");
  })

  $("#flip5").mouseenter(function(){
    $("#panel5").slideToggle("slow");
  })

  $("#flip6").mouseenter(function(){
    $("#panel6").slideToggle("slow");
  })
});

 
 

  

