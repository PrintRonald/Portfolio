# ProLaNEFLA
 LANEFLA

# Ruta a página de 
https://printronald.github.io/ProLaNEFLA/

# Ruta a repositorio de GitHub
https://github.com/PrintRonald/ProLaNEFLA


Se elimina el srchivo ayuda1.html para mantener una buena estructura del conjunto de archivos que
componen el sitio web.

# Agregue algunas funcionalidades con JavaScripts

Se crea a carpeta js y el archivo scripts.js
En este archivo se agregan funciones para visualizar la hora actual en cada una de las páginas del sitio, también
se crea una funcionalidad de alerta para saludar al usuario e invitarlo a ver la galería de trailers y motivarlo a registrarse.

# Ruta a GitHub pages:
https://printronald.github.io/ProLaNEFLA/

# Ruta a repositorio de GitHub:
https://github.com/PrintRonald/ProLaNEFLA

# Se agrega un botón para cambiar el fondo de pantalal en la página galeria.html y se agregan las páginas de reproducción de cada trailers

Se agregan funcionalidades que tienen que ver con la interacción con el ususario para que tenga una mejor experiencia.

# Ruta a Git Hub pages:
https://printronald.github.io/ProLaNEFLA/


# Ruta a repositorio de Git Hab:
https://github.com/PrintRonald/ProLaNEFLA

# Sa agrega un plugin de fancybox 
En la secciín de galería de la página web se integra un carrusel extraido desde
fancybox, aplicando Jquery.

# Ruta a GitHub pages:
https://printronald.github.io/ProLaNEFLA/

# Ruta a repositorio de GitHub:
https://github.com/PrintRonald/ProLaNEFLA




